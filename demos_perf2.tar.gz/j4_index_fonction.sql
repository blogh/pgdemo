CREATE SCHEMA IF NOT EXISTS j4;

\set cls '\\! clear;'
\pset null '¤'
\set ECHO all

:cls
-- *** Création des tables ************************************
DROP TABLE IF EXISTS j4.index_fonctions;
CREATE TABLE j4.index_fonctions(id int PRIMARY KEY, d date);

INSERT INTO j4.index_fonctions(id, d) 
  SELECT x, '2022-01-01'::date - INTERVAL '1 day' * x
    FROM generate_series(1, 10000) AS F(x);

CREATE INDEX ON j4.index_fonctions(d);

\prompt PAUSE
:cls

-- *** Exemple ***********************************************
EXPLAIN (ANALYZE) SELECT * FROM j4.index_fonctions WHERE extract('year' FROM d) = 2023;

CREATE INDEX ON j4.index_fonctions(to_char(d, 'YYYY'));

\prompt PAUSE

CREATE OR REPLACE FUNCTION annee_fr(d date)
  RETURNS int
  AS $$
	SELECT extract('year' from(d AT TIME ZONE 'Europe/Paris')::date);
  $$ 
  LANGUAGE sql 
  IMMUTABLE;

CREATE INDEX ON j4.index_fonctions(annee_fr(d));
EXPLAIN (ANALYZE) SELECT * FROM j4.index_fonctions WHERE annee_fr(d) = 2023;

\prompt PAUSE
