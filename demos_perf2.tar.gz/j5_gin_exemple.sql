CREATE SCHEMA IF NOT EXISTS j5;

\set cls '\\! clear;'
\pset null '¤'
\set ECHO all

:cls
-- *** Création des tables ************************************
DROP TABLE IF EXISTS j5.exp_gin;

CREATE TABLE j5.exp_gin (i int, a int[]) ;
INSERT INTO j5.exp_gin SELECT i, ARRAY[i, i+1] FROM generate_series(1,100000) i ;

\prompt PAUSE
:cls

-- *** Exemple ***********************************************
-- egalité entre tableaux
CREATE INDEX on j5.exp_gin(a);
EXPLAIN (COSTS OFF) SELECT * FROM j5.exp_gin WHERE a = ARRAY[42,43] ;
\prompt PAUSE
:cls

-- tableaux incluse dans
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) SELECT * FROM j5.exp_gin WHERE a @> ARRAY[42] ;
CREATE INDEX ON j5.exp_gin USING gin (a);
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) SELECT * FROM j5.exp_gin WHERE a @> ARRAY[42] ;
\prompt PAUSE
:cls

-- *** Autres exemples **************************************
-- présence d'une clé dans un document json
DROP TABLE IF EXISTS j5.exp_gin_json;
CREATE TABLE j5.exp_gin_json(json jsonb);
INSERT INTO j5.exp_gin_json(json) SELECT ('{"b": "1", "c' || mod(x, 10) || '" : "cccc"}')::jsonb FROM generate_series(1, 10000) AS F(x);

EXPLAIN (ANALYZE) SELECT * FROM j5.exp_gin_json WHERE json ? 'c1';
CREATE INDEX ON j5.exp_gin_json USING GIN(json jsonb_ops);
EXPLAIN (ANALYZE) SELECT * FROM j5.exp_gin_json WHERE json ? 'c1';
\prompt PAUSE
:cls

-- LIKE %string%
DROP TABLE IF EXISTS j5.exp_gin_trgm;
CREATE EXTENSION pg_trgm;
CREATE TABLE j5.exp_gin_trgm(t text);
INSERT INTO j5.exp_gin_trgm(t) SELECT mod(x, 10) || 'Numéro ' || x || ' is called.' FROM generate_series(1, 10000) AS F(x);

EXPLAIN (ANALYZE) SELECT * FROM j5.exp_gin_trgm WHERE t LIKE '% Numéro 10%';
CREATE INDEX ON j5.exp_gin_trgm USING GIN(t gin_trgm_ops);
EXPLAIN (ANALYZE) SELECT * FROM j5.exp_gin_trgm WHERE t LIKE '% Numéro 10%';
\prompt PAUSE
:cls

-- int
DROP TABLE IF EXISTS j5.scalaires;
CREATE EXTENSION btree_gin;
CREATE TABLE j5.scalaires(i int);
INSERT INTO j5.scalaires(i) SELECT mod(x, 100) FROM generate_series(1, 10000) AS F(x);

CREATE INDEX ON j5.scalaires USING gin(i);

EXPLAIN (ANALYZE) SELECT * FROM j5.scalaires WHERE i = 100;

\prompt PAUSE

